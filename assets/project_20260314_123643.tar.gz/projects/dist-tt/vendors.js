"use strict";require("./taro.js");
